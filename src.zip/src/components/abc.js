import React, { useState, useEffect } from 'react';
import * as echarts from 'echarts';
import './StockDashboard.css';

const StockDashboard = () => {
  const [symbol, setSymbol] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [allStockSymbols, setAllStockSymbols] = useState('');
  const [categories, setCategories] = useState({ gainers: [], losers: [], all_stocks: [] });
  const [selectedCategory, setSelectedCategory] = useState('largeCap');

  const fetchStockData = (event) => {
    event.preventDefault();
    if (!symbol || !startDate || !endDate) {
      alert('Please fill in all fields.');
      return;
    }

    const apiUrl = `http://localhost:5001/api/stock?symbol=${symbol}&start_date=${startDate}&end_date=${endDate}`;

    fetch(apiUrl)
      .then((response) => response.json())
      .then((data) => {
        if (Array.isArray(data.candlestick_data) && Array.isArray(data.dates)) {
          const dates = data.dates;
          const candlestickData = data.candlestick_data.map((item) => ({
            name: item[0], // Date
            value: [item[1], item[2], item[3], item[4]], // [Open, High, Low, Close]
          }));

          const chart = echarts.init(document.getElementById('stockChart'));
          const option = {
            title: {
              text: `${symbol} Stock Prices`,
              left: 'center',
              textStyle: { color: '#fff' },
            },
            tooltip: {
              trigger: 'axis',
              axisPointer: { type: 'cross' },
              backgroundColor: 'rgba(50, 50, 50, 0.7)',
              borderColor: '#777',
              borderWidth: 1,
              textStyle: { color: '#fff' },
            },
            grid: {
              left: '5%',
              right: '5%',
              bottom: '10%',
              top: '20%',
            },
            xAxis: {
              type: 'category',
              data: dates,
              boundaryGap: false,
              axisLabel: { color: '#aaa' },
              axisLine: { lineStyle: { color: '#555' } },
              axisTick: { lineStyle: { color: '#555' } },
            },
            yAxis: {
              type: 'value',
              name: 'Price (INR)',
              min: Math.min(...data.candlestick_data.map((item) => item[3])) - 10,
              max: Math.max(...data.candlestick_data.map((item) => item[2])) + 10,
              axisLabel: { color: '#aaa' },
              axisLine: { lineStyle: { color: '#555' } },
              axisTick: { lineStyle: { color: '#555' } },
            },
            backgroundColor: '#121212',
            series: [
              {
                name: 'Candlestick',
                type: 'candlestick',
                data: candlestickData,
                itemStyle: {
                  normal: {
                    color: '#0cf49d',
                    color0: '#ec6a4d',
                    borderColor: '#0cf49d',
                    borderColor0: '#ec6a4d',
                  },
                },
              },
            ],
            dataZoom: [
              { type: 'inside', xAxisIndex: [0], start: 0, end: 100 },
              { type: 'inside', yAxisIndex: [0], start: 0, end: 100 },
            ],
          };
          chart.setOption(option);
        } else {
          alert('Failed to fetch valid stock data.');
        }
      })
      .catch(() => alert('Error fetching stock data'));
  };

  useEffect(() => {
    fetch('http://localhost:5000/api/stocks')
      .then((response) => response.json())
      .then((data) => {
        setAllStockSymbols(data.all_stocks.map((stock) => stock.ticker).join(' | '));
        setCategories({
          gainers: data.gainers,
          losers: data.losers,
          all_stocks: data.all_stocks,
        });
      })
      .catch(() => alert('Error fetching stock categories'));
  }, []);

  const toggleCategory = (category) => {
    setSelectedCategory(category);
  };

  const renderCategoryItems = (items) => {
    return items.map((item, index) => (
      <div key={index} className="stock-item">
        {item.ticker}
      </div>
    ));
  };

  return (
    <div style={{ backgroundColor: '#121212', color: 'white', padding: '20px' }}>
      {/* Marquee */}
      <div id="marquee">
        <span>{allStockSymbols || 'Loading stock data...'}</span>
      </div>

      {/* Stock Form */}
      <h2>Stock Dashboard - {symbol}</h2>
      <form onSubmit={fetchStockData}>
        <label htmlFor="symbol">Stock Symbol: </label>
        <input
          type="text"
          id="symbol"
          value={symbol}
          onChange={(e) => setSymbol(e.target.value)}
          required
        />
        <label htmlFor="start_date">Start Date: </label>
        <input
          type="date"
          id="start_date"
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
          required
        />
        <label htmlFor="end_date">End Date: </label>
        <input
          type="date"
          id="end_date"
          value={endDate}
          onChange={(e) => setEndDate(e.target.value)}
          required
        />
        <button type="submit">Fetch Stock Data</button>
      </form>

      {/* Stock Chart */}
      <div id="stockChart" style={{ width: '100%', height: '500px' }}></div>

      {/* Category Selection */}
      <div style={{ marginTop: '20px' }}>
        <button onClick={() => toggleCategory('largeCap')}>Large Cap</button>
        <button onClick={() => toggleCategory('midCap')}>Mid Cap</button>
        <button onClick={() => toggleCategory('smallCap')}>Small Cap</button>
      </div>

      {/* Stock Categories */}
      <div id="stockCategory" className="stock-category">
        {selectedCategory === 'largeCap' &&
          renderCategoryItems(categories.gainers || [])}
        {selectedCategory === 'midCap' &&
          renderCategoryItems(categories.losers || [])}
        {selectedCategory === 'smallCap' &&
          renderCategoryItems(categories.all_stocks || [])}
      </div>
    </div>
  );
};

export default StockDashboard;
