// src/StockPredictionForm.js
import React, { useState } from 'react';
import {
  Box,
  Button,
  Card,
  CardContent,
  Typography,
  Grid,
  Tooltip,
  MenuItem,
  TextField,
  Paper,
  Tabs,
  Tab,
} from '@mui/material';
import ReactECharts from 'echarts-for-react';
// If you have a StockSuggestions component for ticker lookup, import it;
// Otherwise, you can simply use a TextField for ticker input.
import StockSuggestions from './StockSuggestions';

const StockPredictionForm = () => {
  // Form and state variables.
  const [ticker, setTicker] = useState('');
  const [selectedTerm, setSelectedTerm] = useState('');
  const [predictionResult, setPredictionResult] = useState(null);
  const [realStockData, setRealStockData] = useState([]); // Data from historical API.
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [selectedModel, setSelectedModel] = useState('RandomForest'); // Model to display
  const [chartType, setChartType] = useState('line'); // Chart type selection

  // Calculate start and end dates based on selected term.
  const calculateDates = (term) => {
    const currentDate = new Date();
    let startDate;
    if (term === 'short-term') {
      startDate = new Date(currentDate.getFullYear(), currentDate.getMonth() - 7, currentDate.getDate());
    } else if (term === 'mid-term') {
      startDate = new Date(currentDate.getFullYear(), currentDate.getMonth() - 12, currentDate.getDate());
    } else if (term === 'long-term') {
      startDate = new Date(currentDate.getFullYear(), currentDate.getMonth() - 24, currentDate.getDate());
    }
    return {
      start: startDate.toISOString().split('T')[0],
      end: currentDate.toISOString().split('T')[0],
    };
  };

  const handleTermSelection = (term) => {
    setSelectedTerm(term);
  };

  const handleModelChange = (event, newValue) => {
    setSelectedModel(newValue);
  };

  // Handle form submission: call both prediction and historical APIs.
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    if (!ticker) {
      setError('Please select a stock.');
      return;
    }
    if (!selectedTerm) {
      setError('Please select an investment period.');
      return;
    }
    const { start, end } = calculateDates(selectedTerm);
    try {
      setLoading(true);
      setPredictionResult(null);
      setRealStockData([]);

      // 1. Call prediction API (port 5000)
      const predResponse = await fetch('http://localhost:5000/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ticker, start_date: start, end_date: end, term: selectedTerm }),
      });
      if (!predResponse.ok) {
        const errData = await predResponse.json();
        throw new Error(errData.error || 'Prediction API request failed');
      }
      const predData = await predResponse.json();
      console.log('Prediction API result:', predData);
      setPredictionResult(predData);

      // 2. Fetch historical data from port 4000.
      const histResponse = await fetch(
        `http://localhost:4000/historical/${ticker}?startDate=${start}`
      );
      if (!histResponse.ok) {
        throw new Error('Failed to fetch historical data');
      }
      const histData = await histResponse.json();
      console.log('Historical API result:', histData);
      // Map historical data; check for both uppercase and lowercase keys.
      const realData = (histData.data || []).map((item) => ({
        date: new Date(item.Date || item.date).toLocaleDateString(),
        open: item.Open || item.open,
        high: item.High || item.high,
        low: item.Low || item.low,
        close: item.Close || item.close,
        price: item.Close || item.close, // Using close as plotted value.
      }));
      setRealStockData(realData);
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // Build ECharts options.
  const getChartOptions = () => {
    // Extract predicted series from predictionResult.
    const predictedSeriesRaw =
      predictionResult &&
      predictionResult.chart_data &&
      predictionResult.chart_data.predictions &&
      predictionResult.chart_data.predictions[selectedModel]
        ? predictionResult.chart_data.predictions[selectedModel]
        : [];
    console.log('Raw predicted series:', predictedSeriesRaw);

    // If the predicted series length is less than the real data length, pad with null.
    let predictedSeries = [...predictedSeriesRaw];
    if (realStockData.length > predictedSeries.length) {
      while (predictedSeries.length < realStockData.length) {
        predictedSeries.push(null);
      }
    }
    // Log final predicted series.
    console.log('Final predicted series:', predictedSeries);

    return {
      title: {
        text: `Stock Predictions for ${ticker.toUpperCase()} (${selectedTerm.toUpperCase()})`,
        left: 'center',
      },
      tooltip: {
        trigger: 'axis',
        formatter: function (params) {
          const dataIndex = params[0].dataIndex;
          const realPoint = realStockData[dataIndex] || {};
          let tooltipStr = `<b>Date:</b> ${realPoint.date || 'N/A'}<br/>`;
          tooltipStr += `<b>Open:</b> ₹${realPoint.open || 'N/A'}<br/>`;
          tooltipStr += `<b>High:</b> ₹${realPoint.high || 'N/A'}<br/>`;
          tooltipStr += `<b>Low:</b> ₹${realPoint.low || 'N/A'}<br/>`;
          tooltipStr += `<b>Close:</b> ₹${realPoint.close || 'N/A'}<br/>`;
          params.forEach((item) => {
            tooltipStr += `<b>${item.seriesName}:</b> ₹${item.data !== null ? item.data : 'N/A'}<br/>`;
          });
          return tooltipStr;
        },
      },
      legend: {
        data: ['Real Price', selectedModel],
        bottom: '5%',
        itemGap: 15,
        textStyle: { fontSize: 12 },
      },
      xAxis: {
        type: 'category',
        data: realStockData.map((point) => point.date),
        boundaryGap: chartType === 'bar',
        axisLabel: {
          rotate: 45,
          interval: realStockData.length > 30 ? Math.floor(realStockData.length / 10) : 0,
        },
      },
      yAxis: {
        type: 'value',
        axisLabel: { formatter: '₹{value}' },
      },
      dataZoom: [
        { type: 'slider', xAxisIndex: 0, start: 0, end: 100 },
        { type: 'inside', xAxisIndex: 0 },
      ],
      series: [
        {
          name: 'Real Price',
          type: chartType,
          data: realStockData.map((point) => point.price),
          smooth: chartType === 'line',
          lineStyle: { color: '#4caf50' },
        },
        {
          name: selectedModel,
          type: chartType,
          data: predictedSeries,
          smooth: chartType === 'line',
          lineStyle: { color: '#f44336' },
        },
      ],
    };
  };

  // For evaluation metrics, we simplify the explanation.
  const renderEvaluationMetrics = () => {
    if (!predictionResult || !predictionResult.evaluation_metrics) return null;
    const metrics = predictionResult.evaluation_metrics[selectedModel];
    if (!metrics) return null;
    const mape = metrics.MAPE;
    let performance = '';
    if (mape < 1) performance = 'Excellent';
    else if (mape < 2) performance = 'Good';
    else if (mape < 5) performance = 'Average';
    else performance = 'Poor';
    return (
      <Paper sx={{ p: 2, mt: 4 }}>
        <Typography variant="h6" gutterBottom>
          {selectedModel} Model Performance: {performance}
        </Typography>
        <Typography variant="body2">
          <b>MSE:</b> {metrics.MSE.toFixed(2)} | <b>MAE:</b> {metrics.MAE.toFixed(2)} | <b>MAPE:</b> {metrics.MAPE.toFixed(2)}%
        </Typography>
        <Typography variant="body2" sx={{ mt: 1 }}>
          Lower values indicate predictions are closer to actual prices.
        </Typography>
      </Paper>
    );
  };

  return (
    <Box sx={{ maxWidth: 800, mx: 'auto', mt: 5, p: 3, boxShadow: 3, borderRadius: 2 }}>
      <Typography variant="h4" align="center" gutterBottom sx={{ color: '#1e3a8a' }}>
        Stock Prediction Tool
      </Typography>
      <Typography variant="body1" gutterBottom>
        Enter the stock ticker and select your investment period. The tool predicts the closing price using AI and compares it with real historical data.
      </Typography>
      <Box component="form" onSubmit={handleSubmit} sx={{ mb: 3 }}>
        <Box sx={{ mb: 3 }}>
          {/* Use StockSuggestions if available; otherwise, use a TextField */}
          <StockSuggestions onSelect={setTicker} />
          {/* Alternatively:
          <TextField
            label="Ticker"
            variant="outlined"
            fullWidth
            value={ticker}
            onChange={(e) => setTicker(e.target.value)}
            sx={{ mt: 2 }}
          />
          */}
        </Box>
        <Box sx={{ mb: 2 }}>
          <Typography variant="body1" sx={{ fontWeight: 'bold', mb: 1, color: '#1e40af' }}>
            Select Investment Period:
          </Typography>
          <Grid container spacing={2}>
            {['short-term', 'mid-term', 'long-term'].map((termOption) => (
              <Grid item xs={4} key={termOption}>
                <Tooltip title={`Select ${termOption}`} arrow>
                  <Card
                    onClick={() => handleTermSelection(termOption)}
                    sx={{
                      cursor: 'pointer',
                      border: selectedTerm === termOption ? '2px solid #2563eb' : '1px solid #d1d5db',
                      '&:hover': { transform: 'scale(1.05)' },
                    }}
                  >
                    <CardContent>
                      <Typography variant="h6" align="center" sx={{ color: '#111827' }}>
                        {termOption.toUpperCase()}
                      </Typography>
                    </CardContent>
                  </Card>
                </Tooltip>
              </Grid>
            ))}
          </Grid>
        </Box>
        <Button type="submit" variant="contained" fullWidth sx={{ bgcolor: '#1d4ed8', '&:hover': { bgcolor: '#1e40af' } }}>
          {loading ? 'Loading...' : 'Predict'}
        </Button>
      </Box>
      {error && (
        <Typography variant="body1" color="error" sx={{ mt: 2 }}>
          {error}
        </Typography>
      )}
      {predictionResult && realStockData.length > 0 && (
        <>
          <Box sx={{ mb: 3 }}>
            <Tabs value={selectedModel} onChange={handleModelChange} centered>
              <Tab label="RandomForest" value="RandomForest" />
              <Tab label="XGBoost" value="XGBoost" />
              <Tab label="LSTM" value="LSTM" />
            </Tabs>
          </Box>
          <Box sx={{ mb: 3 }}>
            <TextField
              select
              label="Select Chart Type"
              value={chartType}
              onChange={(e) => setChartType(e.target.value)}
              fullWidth
              sx={{ mb: 3 }}
            >
              <MenuItem value="line">Line Chart</MenuItem>
              <MenuItem value="bar">Bar Chart</MenuItem>
            </TextField>
            <ReactECharts option={getChartOptions()} style={{ height: 400, width: '100%' }} />
          </Box>
          {renderEvaluationMetrics()}
        </>
      )}
    </Box>
  );
};

export default StockPredictionForm;
